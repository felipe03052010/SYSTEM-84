import Layout from '../components/Layout'
import { playClick } from '../utils/audio'
import '../styles/lost-media.css'

const statuses = [
  {
    code: 'STATUS 01',
    title: 'NÃO LOCALIZADA',
    className: 'danger',
    text:
      'A existência da obra é documentada, mas nenhuma cópia verificável foi localizada.',
  },
  {
    code: 'STATUS 02',
    title: 'PARCIALMENTE LOCALIZADA',
    className: 'amber',
    text:
      'Fragmentos, episódios, páginas, imagens ou outros materiais foram encontrados.',
  },
  {
    code: 'STATUS 03',
    title: 'REGISTRO CONFIRMADO',
    className: '',
    text:
      'Fontes confiáveis confirmam a existência e os principais dados históricos da obra.',
  },
  {
    code: 'STATUS 04',
    title: 'CÓPIA LOCALIZADA',
    className: '',
    text:
      'Uma cópia foi identificada; seu status jurídico e a forma de acesso ainda precisam ser verificados.',
  },
  {
    code: 'STATUS 05',
    title: 'DISPONÍVEL LEGALMENTE',
    className: 'success',
    text:
      'Foi identificada uma fonte pública, licenciada ou autorizada para acesso.',
  },
]

export default function LostMedia() {
  return (
    <Layout className="lost-page">
      <section className="lost-hero">
        <div className="lost-warning">
          ! DIRETÓRIO DE RECUPERAÇÃO CULTURAL
        </div>

        <div>
          <span className="directory">
            DIRETÓRIO ESPECIAL / LOST_MEDIA
          </span>

          <h1>
            ARQUIVOS<br />
            PERDIDOS<span className="blink">_</span>
          </h1>

          <p>
            Um espaço para documentar obras cuja existência é conhecida,
            mas que possuem registros incompletos, disponibilidade limitada
            ou localização incerta.
          </p>

          <p className="legal-note">
            O SYSTEM 84 documenta informações e fontes. Ele não incentiva
            distribuição não autorizada de obras protegidas.
          </p>
        </div>

        <aside className="recovery-monitor">
          <div>RECOVERY_MONITOR.EXE</div>
          <p>&gt; rastreamento de fontes........ ATIVO</p>
          <p>&gt; comparação de registros...... ATIVA</p>
          <p>&gt; verificação comunitária...... ATIVA</p>
          <p>&gt; distribuição não autorizada.. BLOQUEADA</p>

          <div className="signal-meter">
            <span />
          </div>

          <small>SINAL DE ARQUIVO: INSTÁVEL</small>
        </aside>
      </section>

      <section className="lost-status">
        <div className="section-heading">
          <span className="directory">PROTOCOLO / STATUS</span>
          <h2>CLASSIFICAÇÃO DOS REGISTROS</h2>
        </div>

        <div className="status-grid">
          {statuses.map((status) => (
            <article key={status.code} className={status.className}>
              <span>{status.code}</span>
              <h3>{status.title}</h3>
              <p>{status.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="case-section">
        <div className="section-heading">
          <span className="directory">RECOVERY / REGISTROS</span>
          <h2>CASOS EM DOCUMENTAÇÃO</h2>
        </div>

        <div className="case-list">
          {['0001', '0002', '0003'].map((code, index) => (
            <article key={code}>
              <span>CASE_84_{code}</span>

              <div>
                <strong>
                  REGISTRO DEMONSTRATIVO {String.fromCharCode(65 + index)}
                </strong>
                <p>
                  Exemplo de entrada que futuramente poderá receber
                  fontes, evidências, histórico de alterações e revisão.
                </p>
              </div>

              <button type="button" onClick={playClick}>
                ABRIR DOSSIÊ &gt;
              </button>
            </article>
          ))}
        </div>
      </section>
    </Layout>
  )
}

export const records = [
  {
    id: 1,
    type: 'filme',
    title: 'Nosferatu',
    year: 1922,
    code: 'FILM_1922_001',
    description:
      'Um dos registros mais conhecidos do expressionismo alemão e do cinema de horror silencioso.',
    tags: ['terror', 'mudo', 'expressionismo'],
  },
  {
    id: 2,
    type: 'filme',
    title: 'Metropolis',
    year: 1927,
    code: 'FILM_1927_002',
    description:
      'Ficção científica de Fritz Lang conhecida por sua escala visual e visão futurista.',
    tags: ['ficção científica', 'clássico'],
  },
  {
    id: 3,
    type: 'filme',
    title: 'O Gabinete do Dr. Caligari',
    year: 1920,
    code: 'FILM_1920_003',
    description:
      'Obra central do expressionismo alemão, marcada por cenários distorcidos e atmosfera psicológica.',
    tags: ['terror', 'expressionismo'],
  },
  {
    id: 4,
    type: 'filme',
    title: 'Viagem à Lua',
    year: 1902,
    code: 'FILM_1902_004',
    description:
      'Curta de Georges Méliès lembrado por efeitos visuais pioneiros e imaginação fantástica.',
    tags: ['fantasia', 'curta'],
  },
  {
    id: 5,
    type: 'série',
    title: 'The Twilight Zone',
    year: 1959,
    code: 'TV_1959_001',
    description:
      'Antologia de ficção científica, fantasia e suspense criada por Rod Serling.',
    tags: ['antologia', 'ficção científica'],
  },
  {
    id: 6,
    type: 'série',
    title: 'Alfred Hitchcock Presents',
    year: 1955,
    code: 'TV_1955_002',
    description:
      'Antologia televisiva de suspense associada à apresentação de Alfred Hitchcock.',
    tags: ['suspense', 'antologia'],
  },
  {
    id: 7,
    type: 'série',
    title: 'The Prisoner',
    year: 1967,
    code: 'TV_1967_003',
    description:
      'Série britânica marcada por mistério, espionagem e temas de identidade e controle.',
    tags: ['mistério', 'espionagem'],
  },
  {
    id: 8,
    type: 'série',
    title: 'The Outer Limits',
    year: 1963,
    code: 'TV_1963_004',
    description:
      'Antologia norte-americana de ficção científica e horror produzida originalmente nos anos 1960.',
    tags: ['ficção científica', 'horror'],
  },
  {
    id: 9,
    type: 'livro',
    title: 'Frankenstein',
    year: 1818,
    code: 'BOOK_1818_001',
    description:
      'Romance de Mary Shelley sobre criação, responsabilidade e os limites da ciência.',
    tags: ['gótico', 'ficção científica'],
  },
  {
    id: 10,
    type: 'livro',
    title: 'Drácula',
    year: 1897,
    code: 'BOOK_1897_002',
    description:
      'Romance epistolar de Bram Stoker que se tornou uma referência da literatura gótica.',
    tags: ['gótico', 'terror'],
  },
  {
    id: 11,
    type: 'livro',
    title: 'O Retrato de Dorian Gray',
    year: 1890,
    code: 'BOOK_1890_003',
    description:
      'Romance de Oscar Wilde sobre beleza, moralidade, influência e decadência.',
    tags: ['gótico', 'clássico'],
  },
  {
    id: 12,
    type: 'livro',
    title: 'A Máquina do Tempo',
    year: 1895,
    code: 'BOOK_1895_004',
    description:
      'Romance de H. G. Wells sobre viagem temporal, sociedade e transformação humana.',
    tags: ['ficção científica', 'clássico'],
  },
]

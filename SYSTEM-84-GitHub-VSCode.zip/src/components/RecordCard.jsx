import { playClick } from '../utils/audio'

export default function RecordCard({ record }) {
  function openRecord() {
    playClick()
    alert(
      `Registro: ${record.title}\n\n` +
      'A página individual da obra poderá ser conectada depois ao banco de dados.'
    )
  }

  return (
    <article className="record-card">
      <div className="record-cover">
        <span className="record-code">{record.code}</span>

        <div className="cover-placeholder">
          <span>ARQUIVO VISUAL</span>
          <strong>{record.title}</strong>
          <small>
            {record.type.toUpperCase()} // {record.year}
          </small>
        </div>
      </div>

      <div className="record-content">
        <span className="record-meta">
          {record.type.toUpperCase()} // {record.year}
        </span>

        <h3>{record.title}</h3>
        <p>{record.description}</p>

        <div className="record-tags">
          {record.tags.map((tag) => (
            <span key={tag}>{tag}</span>
          ))}
        </div>

        <button className="terminal-action" type="button" onClick={openRecord}>
          ABRIR REGISTRO &gt;
        </button>
      </div>
    </article>
  )
}
